DUSMP Launcher 1.3.1 - Linux x86-64

Requirements: glibc 2.38+; GTK 3; WebKitGTK 4.1; graphical desktop.
Debian/Ubuntu packages: libgtk-3-0 (or libgtk-3-0t64), libwebkit2gtk-4.1-0.
Extract this archive, then run: bash install.sh
The installer creates shortcuts in the application menu and on your desktop.
Or run ./DusmpLauncher directly from a writable user-owned directory.
No sudo is needed. Do not move it into /usr/bin or a package-manager-owned directory.
The launcher verifies signed updates automatically before opening the main interface.
Accounts/settings/Minecraft data: ~/.local/share/DusmpLauncher (kept during updates).
DusmpUpdater is the separate optional background modpack updater. The installer does not enable a system service.
The launcher update mechanism does not update package-manager-owned installations.
This is a tar.gz bundle, not an AppImage. WebKitGTK and GTK must be installed.
